<div class="mep-event-thumbnail">
    <?php the_post_thumbnail('full'); ?>
</div>