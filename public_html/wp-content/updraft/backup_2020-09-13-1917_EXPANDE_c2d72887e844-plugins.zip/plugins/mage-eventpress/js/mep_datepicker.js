jQuery(document).ready(function($){
      // var startDateTextBox = jQuery('.event_start');
      // var endDateTextBox = jQuery('.event_end');
      // jQuery.timepicker.datetimeRange(
      //   startDateTextBox,
      //   endDateTextBox,
      //   {
      //     minInterval: (1000*60*60), // 1hr
      //     dateFormat: 'yy-mm-dd', 
      //     timeFormat: 'HH:mm',
      //     start: {}, // start picker options
      //     end: {} // end picker options         
      //   }
      // );


      // jQuery('.event_more_date').datetimepicker({
      //   dateFormat: 'yy-mm-dd', 
      //   timeFormat: "HH:mm"
      //    // minDate:0
      // });


       jQuery('.event_more_date').datetimepicker({
         dateFormat: 'yy-mm-dd', 
         timeFormat: "HH:mm"
          // minDate:0
       });


    }); 